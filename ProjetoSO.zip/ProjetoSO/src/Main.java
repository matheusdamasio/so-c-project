import java.util.concurrent.Semaphore;


public class Main extends Thread {

    private int jogador;
    private Semaphore sem;

    public Main(int jogador, Semaphore sem) {
        this.jogador = jogador; //thread
        this.sem = sem; //semaforo
    }

    private void espera() {  //Processo está dormindo
        try {
            System.out.println("Jogador " + jogador + " espera");
            Thread.sleep((long) (Math.random() * 10000));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    private void turno() {  //Processo está dormindo
        try {
            System.out.println("Jogador " + jogador + " joga");
            Thread.sleep((long) (Math.random() * 10000));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
        

    private void naoJoga() {  //Regiao não crítica
        System.out.println("Jogador " + jogador + " não joga");
        espera();
    }

    private void Joga() {  //Região Crítica
        System.out.println("Início do turno do Jogador "+ jogador);
        turno();
        System.out.println("Fim do turno do Jogador "+jogador);
    }

    @Override
    public void run() {  //Roda as funções
        naoJoga(); //inicia as threads fora da região crítica
        System.out.println();
        try {
            sem.acquire();//Requisita o acesso ao recurso do semáforo
            Joga();  //A threads entram e saem da região crítica, uma por vez
            System.out.println();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } finally {
            sem.release();//Libera o recurso do semáforo
        }
    }

    public static void main(String[] args) {
        int jogadoresemturno = 1; //Quantas threads entram na região crítica de cada vez
        int jogadores = 3; //Quantas threads serão usadas
        Semaphore sem = new Semaphore(jogadoresemturno);
        Main[] processo = new Main[jogadores];
        for (int i = 0; i < jogadores; i++) {
            processo[i] = new Main(i, sem);
            processo[i].start();
        }
    }
}
